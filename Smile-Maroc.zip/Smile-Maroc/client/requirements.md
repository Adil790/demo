## Packages
(none needed)

## Notes
Uses existing stack only (React, Tailwind, TanStack Query, wouter, lucide-react, framer-motion already installed).
WhatsApp CTA uses https://wa.me/212781266654 with prefilled text (urlencoded).
Phone CTA uses tel:+212523340663 (mobile-friendly).
Google Maps embedded via iframe with address query (no placeId required).
All key interactive elements include data-testid.
