import { ShieldPlus } from "lucide-react";

export default function BrandMark({
  compact = false,
  className = "",
}: {
  compact?: boolean;
  className?: string;
}) {
  return (
    <div className={`flex items-center gap-3 ${className}`} data-testid="brand">
      <div
        className="relative grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-primary to-accent shadow-premium ring-1 ring-white/35"
        aria-hidden="true"
      >
        <ShieldPlus className="h-5 w-5 text-primary-foreground" />
        <div className="pointer-events-none absolute -right-2 -top-2 h-6 w-6 rounded-full bg-white/70 blur-[1px]" />
      </div>

      <div className="min-w-0">
        <div className="truncate text-sm font-extrabold tracking-tight md:text-base">
          <span className="text-gradient-medical">Dr. Ahmed Rida</span>{" "}
          <span className="text-foreground">FADIL</span>
        </div>
        {!compact && (
          <div className="truncate text-xs font-semibold text-muted-foreground">
            Cabinet dentaire • El Jadida
          </div>
        )}
      </div>
    </div>
  );
}
