import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export default function IconPill({
  icon: Icon,
  title,
  description,
  tone = "primary",
  className,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  tone?: "primary" | "accent";
  className?: string;
}) {
  const toneCls =
    tone === "accent"
      ? "from-accent/18 to-accent/6 ring-accent/15"
      : "from-primary/18 to-primary/6 ring-primary/15";

  const iconTone =
    tone === "accent" ? "text-accent" : "text-primary";

  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-3xl border border-border/60 bg-gradient-to-br p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-premium",
        toneCls,
        className,
      )}
      data-testid="icon-pill"
    >
      <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-white/35 blur-2xl transition-opacity duration-300 group-hover:opacity-80" />
      <div className="flex items-start gap-4">
        <div
          className="grid h-11 w-11 place-items-center rounded-2xl bg-card/80 ring-1 ring-border/70 shadow-sm"
          aria-hidden="true"
        >
          <Icon className={cn("h-5 w-5", iconTone)} />
        </div>
        <div className="min-w-0">
          <div className="text-base font-extrabold tracking-tight">{title}</div>
          <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
            {description}
          </p>
        </div>
      </div>
    </div>
  );
}
