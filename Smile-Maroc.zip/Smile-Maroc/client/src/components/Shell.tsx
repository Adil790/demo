import { ReactNode, useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "wouter";
import { AnimatePresence, motion } from "framer-motion";
import { MapPin, Phone, MessageCircle, ArrowUpRight } from "lucide-react";
import BrandMark from "@/components/BrandMark";
import GradientButton from "@/components/GradientButton";
import { siteConfig } from "@/components/SiteConfig";
import { cn } from "@/lib/utils";

function useScrollY(threshold = 8) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > threshold);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [threshold]);
  return scrolled;
}

function NavLink({
  href,
  label,
  testid,
}: {
  href: string;
  label: string;
  testid: string;
}) {
  const [location] = useLocation();
  const active = location === href;
  return (
    <Link
      href={href}
      data-testid={testid}
      className={cn(
        "rounded-xl px-3 py-2 text-sm font-extrabold tracking-tight transition-all duration-300",
        active
          ? "bg-primary/10 text-primary"
          : "text-muted-foreground hover:text-foreground hover:bg-card/70",
      )}
    >
      {label}
    </Link>
  );
}

export default function Shell({ children }: { children: ReactNode }) {
  const scrolled = useScrollY(10);

  const whatsappText = useMemo(
    () =>
      `Bonjour, je souhaite prendre rendez-vous au ${siteConfig.clinicName} à El Jadida.`,
    [],
  );

  const waHref = siteConfig.whatsappHref(whatsappText);

  return (
    <div className="min-h-dvh bg-mesh-clinic">
      <div className="pointer-events-none fixed inset-0 bg-grid-medical opacity-[0.55]" />
      <div className="pointer-events-none fixed inset-x-0 top-0 h-24 bg-gradient-to-b from-background via-background/60 to-transparent" />

      <header
        className={cn(
          "sticky top-0 z-40",
          scrolled ? "backdrop-blur supports-[backdrop-filter]:bg-background/65" : "bg-transparent",
        )}
        data-testid="header"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={cn(
              "mt-3 mb-3 rounded-3xl border transition-all duration-300",
              scrolled ? "border-border/70 shadow-premium glass-surface" : "border-transparent",
            )}
          >
            <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-5">
              <Link href="/" className="rounded-2xl focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20" data-testid="nav-home">
                <BrandMark />
              </Link>

              <nav className="hidden items-center gap-1 md:flex" aria-label="Navigation principale">
                <NavLink href="/" label="Accueil" testid="nav-accueil" />
                <NavLink href="/a-propos" label="À propos" testid="nav-apropos" />
                <NavLink href="/soins" label="Nos soins" testid="nav-soins" />
                <NavLink href="/contact" label="Contact" testid="nav-contact" />
              </nav>

              <div className="flex items-center gap-2">
                <a
                  href={siteConfig.phoneHref}
                  className="hidden md:inline-flex"
                  data-testid="cta-call-desktop"
                  aria-label="Appeler le cabinet"
                >
                  <GradientButton variant="ghost" size="sm" onClick={() => {}}>
                    <Phone className="h-4 w-4" />
                    Appeler
                    <ArrowUpRight className="h-4 w-4 opacity-70" />
                  </GradientButton>
                </a>

                <a
                  href={waHref}
                  target="_blank"
                  rel="noreferrer"
                  data-testid="cta-whatsapp-header"
                  aria-label="Prendre rendez-vous sur WhatsApp"
                >
                  <GradientButton variant="primary" size="sm" onClick={() => {}}>
                    <MessageCircle className="h-4 w-4" />
                    WhatsApp RDV
                  </GradientButton>
                </a>
              </div>
            </div>

            <div className="border-t border-border/60 px-4 py-2 md:hidden">
              <div className="flex items-center justify-between gap-2 text-xs font-semibold text-muted-foreground">
                <div className="inline-flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="truncate">{siteConfig.locationLine}</span>
                </div>
                <Link
                  href="/rendez-vous"
                  className="rounded-full bg-primary/10 px-3 py-1 font-extrabold text-primary transition hover:bg-primary/15"
                  data-testid="nav-mobile-rdv"
                >
                  RDV
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      <AnimatePresence mode="wait">
        <motion.main
          key={typeof window !== "undefined" ? window.location.pathname : "page"}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 8 }}
          transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
          className="relative z-10"
          data-testid="main"
        >
          {children}
        </motion.main>
      </AnimatePresence>

      <footer className="relative z-10 mt-20 border-t border-border/70 bg-background/65 backdrop-blur" data-testid="footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div>
              <BrandMark />
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                Soins dentaires modernes à El Jadida, avec une approche centrée sur
                l’hygiène, la précision et le confort patient.
              </p>
            </div>

            <div>
              <div className="text-sm font-extrabold tracking-tight">Coordonnées</div>
              <div className="mt-4 space-y-3 text-sm text-muted-foreground">
                <div className="flex items-start gap-3">
                  <MapPin className="mt-0.5 h-4 w-4 text-primary" />
                  <div className="leading-relaxed">
                    <div className="font-semibold text-foreground">{siteConfig.address}</div>
                    <div className="text-xs">{siteConfig.locationLine}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-primary" />
                  <a
                    href={siteConfig.phoneHref}
                    className="font-semibold text-foreground underline decoration-primary/20 hover:decoration-primary/60"
                    data-testid="footer-phone"
                  >
                    {siteConfig.phoneDisplay}
                  </a>
                </div>
                <div className="flex items-center gap-3">
                  <MessageCircle className="h-4 w-4 text-accent" />
                  <a
                    href={waHref}
                    target="_blank"
                    rel="noreferrer"
                    className="font-semibold text-foreground underline decoration-accent/20 hover:decoration-accent/60"
                    data-testid="footer-whatsapp"
                  >
                    WhatsApp RDV: {siteConfig.whatsappDisplay}
                  </a>
                </div>
              </div>
            </div>

            <div>
              <div className="text-sm font-extrabold tracking-tight">Navigation</div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-sm font-semibold">
                <Link href="/" className="rounded-xl px-3 py-2 text-muted-foreground hover:bg-card/70 hover:text-foreground" data-testid="footer-nav-accueil">
                  Accueil
                </Link>
                <Link href="/soins" className="rounded-xl px-3 py-2 text-muted-foreground hover:bg-card/70 hover:text-foreground" data-testid="footer-nav-soins">
                  Nos soins
                </Link>
                <Link href="/a-propos" className="rounded-xl px-3 py-2 text-muted-foreground hover:bg-card/70 hover:text-foreground" data-testid="footer-nav-apropos">
                  À propos
                </Link>
                <Link href="/contact" className="rounded-xl px-3 py-2 text-muted-foreground hover:bg-card/70 hover:text-foreground" data-testid="footer-nav-contact">
                  Contact
                </Link>
                <Link href="/rendez-vous" className="col-span-2 rounded-xl px-3 py-2 text-primary hover:bg-primary/10" data-testid="footer-nav-rdv">
                  Prendre rendez-vous
                </Link>
              </div>

              <div className="mt-6 rounded-2xl border border-border/60 bg-card/70 p-4 shadow-sm">
                <div className="text-xs font-extrabold text-muted-foreground">SEO local</div>
                <div className="mt-2 text-sm font-bold text-foreground">
                  Dentiste El Jadida • Cabinet dentaire • Urgence dentaire
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  Des soins clairs, des explications simples, et une prise de RDV rapide.
                </div>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-col gap-2 border-t border-border/70 pt-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
            <div>© {new Date().getFullYear()} {siteConfig.clinicName}. Tous droits réservés.</div>
            <div className="inline-flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" aria-hidden="true" />
              <span>Site optimisé conversion: Appel + WhatsApp</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating conversion buttons */}
      <a
        href={waHref}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-accent to-accent/80 px-4 py-3 text-sm font-extrabold text-accent-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg active:translate-y-0 transition-all duration-300"
        data-testid="floating-whatsapp"
        aria-label="WhatsApp RDV"
        onClick={() => {}}
      >
        <MessageCircle className="h-5 w-5" />
        WhatsApp
      </a>

      <a
        href={siteConfig.phoneHref}
        className="fixed bottom-5 left-5 z-50 inline-flex items-center gap-2 rounded-2xl bg-gradient-to-r from-primary to-primary/80 px-4 py-3 text-sm font-extrabold text-primary-foreground shadow-premium hover:-translate-y-0.5 hover:shadow-premium-lg active:translate-y-0 transition-all duration-300 md:hidden"
        data-testid="floating-call"
        aria-label="Appeler maintenant"
        onClick={() => {}}
      >
        <Phone className="h-5 w-5" />
        Appeler
      </a>
    </div>
  );
}
