import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { MessageCircle, Phone, Mail, Sparkles } from "lucide-react";
import { api, type CreateLeadInput } from "@shared/routes";
import { SERVICE_OPTIONS } from "@shared/schema";
import { useCreateLead } from "@/hooks/use-leads";
import { useToast } from "@/hooks/use-toast";
import GradientButton from "@/components/GradientButton";
import { cn } from "@/lib/utils";
import { siteConfig } from "@/components/SiteConfig";

const formSchema = api.leads.create.input.extend({
  // Coercions not needed (all strings), but keep robust.
  fullName: z.string().min(2, "Veuillez entrer votre nom complet."),
  phone: z.string().min(6, "Veuillez entrer un numéro valide."),
  message: z.string().min(4, "Dites-nous brièvement votre besoin."),
  service: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

function ChannelChip({
  value,
  selected,
  label,
  icon: Icon,
  onClick,
  testid,
}: {
  value: CreateLeadInput["preferredChannel"];
  selected: boolean;
  label: string;
  icon: any;
  onClick: () => void;
  testid: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-testid={testid}
      className={cn(
        "group inline-flex items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-extrabold transition-all duration-300",
        selected
          ? "border-primary/30 bg-primary/10 text-primary shadow-sm"
          : "border-border/70 bg-card/60 text-muted-foreground hover:bg-card hover:text-foreground hover:-translate-y-0.5 hover:shadow-premium",
      )}
    >
      <Icon className={cn("h-4 w-4", selected ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
      {label}
    </button>
  );
}

export default function LeadForm({
  defaultService,
  className,
  onSubmitted,
}: {
  defaultService?: string;
  className?: string;
  onSubmitted?: () => void;
}) {
  const { toast } = useToast();
  const createLead = useCreateLead();

  const initialMessage = useMemo(() => {
    const base = "Bonjour, je souhaite prendre rendez-vous.";
    return defaultService ? `${base} Concernant: ${defaultService}.` : base;
  }, [defaultService]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      phone: "",
      preferredChannel: "whatsapp",
      message: initialMessage,
      service: defaultService,
    },
    mode: "onChange",
  });

  useEffect(() => {
    // Keep message aligned when service changes
    if (defaultService) {
      form.setValue("service", defaultService, { shouldValidate: true });
      form.setValue(
        "message",
        `Bonjour, je souhaite prendre rendez-vous. Concernant: ${defaultService}.`,
        { shouldValidate: true },
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [defaultService]);

  const preferredChannel = form.watch("preferredChannel");
  const service = form.watch("service");

  const waPrefill = useMemo(() => {
    const v = form.getValues();
    const lines = [
      `Bonjour, je m'appelle ${v.fullName || "[Nom]"}.`,
      `Mon numéro: ${v.phone || "[Téléphone]"}.`,
      v.service ? `Soin: ${v.service}.` : undefined,
      v.message ? `Message: ${v.message}` : undefined,
      `Cabinet: ${siteConfig.clinicName} (El Jadida).`,
    ].filter(Boolean) as string[];
    return lines.join("\n");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preferredChannel, service, form.formState.isValid]);

  async function onSubmit(values: FormValues) {
    try {
      const payload: CreateLeadInput = {
        fullName: values.fullName,
        phone: values.phone,
        preferredChannel: values.preferredChannel,
        message: values.message,
        service: values.service,
      };

      const created = await createLead.mutateAsync(payload);

      toast({
        title: "Demande envoyée",
        description:
          values.preferredChannel === "whatsapp"
            ? "Vous pouvez maintenant ouvrir WhatsApp pour confirmer votre RDV."
            : "Nous vous recontacterons très rapidement.",
      });

      onSubmitted?.();

      // If WhatsApp chosen, open WhatsApp with context
      if (values.preferredChannel === "whatsapp") {
        const href = siteConfig.whatsappHref(
          `Bonjour, je confirme ma demande de RDV.\nRéférence: #${created.id}\n\n${waPrefill}`,
        );
        window.open(href, "_blank", "noopener,noreferrer");
      }

      form.reset({
        ...values,
        message: initialMessage,
        fullName: "",
        phone: "",
        preferredChannel: "whatsapp",
        service: values.service,
      });
    } catch (e: any) {
      toast({
        title: "Impossible d'envoyer",
        description: e?.message ?? "Veuillez réessayer.",
        variant: "destructive",
      });
    }
  }

  return (
    <div className={cn("rounded-3xl border border-border/70 bg-card/70 p-6 shadow-premium backdrop-blur noise-overlay", className)} data-testid="lead-form">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-extrabold text-primary">
            <Sparkles className="h-4 w-4" />
            RDV rapide
          </div>
          <h3 className="mt-3 text-xl font-bold leading-tight md:text-2xl">
            Demandez un rendez-vous en 30 secondes
          </h3>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Laissez vos coordonnées. Nous confirmons rapidement par le canal de votre choix.
          </p>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3" data-testid="lead-channel">
        <ChannelChip
          value="whatsapp"
          selected={preferredChannel === "whatsapp"}
          label="WhatsApp"
          icon={MessageCircle}
          onClick={() => form.setValue("preferredChannel", "whatsapp", { shouldValidate: true })}
          testid="channel-whatsapp"
        />
        <ChannelChip
          value="call"
          selected={preferredChannel === "call"}
          label="Appel"
          icon={Phone}
          onClick={() => form.setValue("preferredChannel", "call", { shouldValidate: true })}
          testid="channel-call"
        />
        <ChannelChip
          value="email"
          selected={preferredChannel === "email"}
          label="Email"
          icon={Mail}
          onClick={() => form.setValue("preferredChannel", "email", { shouldValidate: true })}
          testid="channel-email"
        />
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="mt-6 space-y-4" data-testid="lead-form-form">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label className="text-sm font-extrabold tracking-tight" htmlFor="fullName">
              Nom complet
            </label>
            <input
              id="fullName"
              data-testid="input-fullname"
              {...form.register("fullName")}
              className="mt-2 w-full rounded-2xl border-2 border-input bg-background/70 px-4 py-3 text-sm font-semibold text-foreground placeholder:text-muted-foreground shadow-sm transition-all duration-200 focus:border-primary focus:ring-4 focus:ring-primary/10 focus:outline-none"
              placeholder="Ex: Sara El Amrani"
              autoComplete="name"
            />
            {form.formState.errors.fullName && (
              <p className="mt-2 text-xs font-semibold text-destructive" data-testid="error-fullname">
                {form.formState.errors.fullName.message}
              </p>
            )}
          </div>

          <div>
            <label className="text-sm font-extrabold tracking-tight" htmlFor="phone">
              Téléphone
            </label>
            <input
              id="phone"
              data-testid="input-phone"
              {...form.register("phone")}
              className="mt-2 w-full rounded-2xl border-2 border-input bg-background/70 px-4 py-3 text-sm font-semibold text-foreground placeholder:text-muted-foreground shadow-sm transition-all duration-200 focus:border-primary focus:ring-4 focus:ring-primary/10 focus:outline-none"
              placeholder="Ex: 06 xx xx xx xx"
              inputMode="tel"
              autoComplete="tel"
            />
            {form.formState.errors.phone && (
              <p className="mt-2 text-xs font-semibold text-destructive" data-testid="error-phone">
                {form.formState.errors.phone.message}
              </p>
            )}
          </div>
        </div>

        <div>
          <label className="text-sm font-extrabold tracking-tight" htmlFor="service">
            Soin (optionnel)
          </label>
          <select
            id="service"
            data-testid="select-service"
            {...form.register("service")}
            className="mt-2 w-full rounded-2xl border-2 border-input bg-background/70 px-4 py-3 text-sm font-semibold text-foreground shadow-sm transition-all duration-200 focus:border-primary focus:ring-4 focus:ring-primary/10 focus:outline-none"
          >
            <option value="">Choisir un soin</option>
            {SERVICE_OPTIONS.map((opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="text-sm font-extrabold tracking-tight" htmlFor="message">
            Message
          </label>
          <textarea
            id="message"
            data-testid="textarea-message"
            {...form.register("message")}
            className="mt-2 min-h-[110px] w-full resize-none rounded-2xl border-2 border-input bg-background/70 px-4 py-3 text-sm font-semibold text-foreground placeholder:text-muted-foreground shadow-sm transition-all duration-200 focus:border-primary focus:ring-4 focus:ring-primary/10 focus:outline-none"
            placeholder="Ex: douleur / contrôle / devis implant..."
          />
          {form.formState.errors.message && (
            <p className="mt-2 text-xs font-semibold text-destructive" data-testid="error-message">
              {form.formState.errors.message.message}
            </p>
          )}
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-xs text-muted-foreground">
            En envoyant, vous acceptez d’être recontacté par le cabinet.
          </div>
          <GradientButton
            type="submit"
            variant="accent"
            size="md"
            disabled={!form.formState.isValid || createLead.isPending}
            data-testid="submit-lead"
            onClick={() => {}}
            className="sm:min-w-[220px]"
          >
            {createLead.isPending ? "Envoi..." : "Envoyer la demande"}
          </GradientButton>
        </div>

        {preferredChannel === "whatsapp" && (
          <div className="rounded-2xl border border-border/70 bg-background/60 p-4 text-sm shadow-sm" data-testid="wa-preview">
            <div className="flex items-center justify-between gap-3">
              <div className="font-extrabold tracking-tight">Pré-remplissage WhatsApp</div>
              <a
                href={siteConfig.whatsappHref(waPrefill)}
                target="_blank"
                rel="noreferrer"
                data-testid="wa-open"
                className="inline-flex items-center gap-2 rounded-xl bg-accent/12 px-3 py-2 text-xs font-extrabold text-accent hover:bg-accent/16 transition"
                onClick={() => {}}
              >
                <MessageCircle className="h-4 w-4" />
                Ouvrir
              </a>
            </div>
            <pre className="mt-3 whitespace-pre-wrap break-words rounded-xl bg-card/70 p-3 text-xs text-muted-foreground">
              {waPrefill}
            </pre>
          </div>
        )}
      </form>
    </div>
  );
}
