import * as React from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "accent" | "ghost";

export default function GradientButton({
  variant = "primary",
  size = "md",
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: "sm" | "md" | "lg";
}) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-2xl font-bold tracking-tight " +
    "transition-all duration-300 ease-out " +
    "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20 " +
    "disabled:opacity-60 disabled:cursor-not-allowed disabled:transform-none";

  const sizes = {
    sm: "px-4 py-2.5 text-sm",
    md: "px-5 py-3 text-sm md:text-base",
    lg: "px-6 py-3.5 text-base md:text-lg",
  }[size];

  const variants: Record<Variant, string> = {
    primary:
      "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground shadow-premium " +
      "hover:shadow-premium-lg hover:-translate-y-0.5 active:translate-y-0 active:shadow-premium",
    accent:
      "bg-gradient-to-r from-accent to-accent/80 text-accent-foreground shadow-premium " +
      "hover:shadow-premium-lg hover:-translate-y-0.5 active:translate-y-0 active:shadow-premium",
    ghost:
      "bg-card/70 text-foreground border border-border/70 shadow-sm backdrop-blur " +
      "hover:bg-card hover:-translate-y-0.5 hover:shadow-premium active:translate-y-0",
  };

  return (
    <button className={cn(base, sizes, variants[variant], className)} {...props} />
  );
}
