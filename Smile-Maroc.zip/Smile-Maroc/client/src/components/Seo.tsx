import { useEffect } from "react";

type SeoProps = {
  title: string;
  description: string;
  path?: string;
  keywords?: string;
};

const SITE_NAME = "Cabinet Dentaire Dr. Ahmed Rida FADIL";

export default function Seo({ title, description, path = "/", keywords }: SeoProps) {
  useEffect(() => {
    const fullTitle = `${title} — ${SITE_NAME}`;
    document.title = fullTitle;

    const ensureMeta = (name: string, attr: "name" | "property" = "name") => {
      const selector = attr === "name" ? `meta[name="${name}"]` : `meta[property="${name}"]`;
      let el = document.head.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      return el;
    };

    ensureMeta("description").content = description;
    ensureMeta("keywords").content =
      keywords ??
      "Dentiste El Jadida, Cabinet dentaire El Jadida, Urgence dentaire El Jadida, Détartrage, Blanchiment, Implant, Orthodontie";

    // OpenGraph basics
    ensureMeta("og:title", "property").content = fullTitle;
    ensureMeta("og:description", "property").content = description;
    ensureMeta("og:type", "property").content = "website";
    ensureMeta("og:locale", "property").content = "fr_MA";

    const canonicalUrl = `${window.location.origin}${path}`;
    let canonical = document.head.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.rel = "canonical";
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;

    ensureMeta("og:url", "property").content = canonicalUrl;
  }, [title, description, path, keywords]);

  return null;
}
