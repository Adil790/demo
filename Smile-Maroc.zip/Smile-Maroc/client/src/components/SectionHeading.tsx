export default function SectionHeading({
  kicker,
  title,
  description,
  align = "left",
  className = "",
}: {
  kicker?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  className?: string;
}) {
  const alignCls = align === "center" ? "text-center mx-auto" : "text-left";
  return (
    <div className={`${alignCls} ${className}`}>
      {kicker && (
        <div className="inline-flex items-center gap-2 rounded-full border bg-card/60 px-3 py-1 text-xs font-extrabold tracking-wide text-muted-foreground shadow-sm">
          <span className="h-1.5 w-1.5 rounded-full bg-accent" aria-hidden="true" />
          <span>{kicker}</span>
        </div>
      )}
      <h2 className="mt-4 text-2xl font-bold leading-tight md:text-3xl">
        {title}
      </h2>
      {description && (
        <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted-foreground md:text-base">
          {description}
        </p>
      )}
    </div>
  );
}
