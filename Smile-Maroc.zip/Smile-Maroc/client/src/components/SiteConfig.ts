export const siteConfig = {
  clinicName: "Cabinet Dentaire Dr. Ahmed Rida FADIL",
  address: "Résidence Alami, 10 Bd Mohamed V, El Jadida 24000",
  locationLine: "El Jadida – Résidence Alami (face à Bank Al Maghrib)",
  phoneDisplay: "05 23 34 06 63",
  phoneHref: "tel:+212523340663",
  whatsappDisplay: "07 81 26 66 54",
  whatsappNumber: "212781266654",
  whatsappHref: (text: string) =>
    `https://wa.me/212781266654?text=${encodeURIComponent(text)}`,
  mapsEmbedUrl:
    "https://www.google.com/maps?q=R%C3%A9sidence%20Alami%2C%2010%20Bd%20Mohamed%20V%2C%20El%20Jadida%2024000&output=embed",
} as const;
