import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export default function ServiceCard({
  icon: Icon,
  title,
  bullets,
  highlight,
  className,
  onCta,
}: {
  icon: LucideIcon;
  title: string;
  bullets: string[];
  highlight?: string;
  className?: string;
  onCta: () => void;
}) {
  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-3xl border border-border/60 bg-card/70 p-6 shadow-sm backdrop-blur transition-all duration-300 hover:-translate-y-1 hover:shadow-premium",
        className,
      )}
      data-testid={`service-card-${title}`}
    >
      <div className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-primary/10 blur-2xl transition-opacity duration-300 group-hover:opacity-80" />
      <div className="pointer-events-none absolute -bottom-16 -left-16 h-44 w-44 rounded-full bg-accent/10 blur-2xl transition-opacity duration-300 group-hover:opacity-80" />

      <div className="flex items-start gap-4">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-primary/15 to-accent/10 ring-1 ring-border/70">
          <Icon className="h-5 w-5 text-primary" />
        </div>
        <div className="min-w-0">
          <div className="text-lg font-extrabold tracking-tight">{title}</div>
          {highlight && (
            <div className="mt-2 inline-flex items-center rounded-full bg-accent/12 px-3 py-1 text-xs font-extrabold text-accent">
              {highlight}
            </div>
          )}
        </div>
      </div>

      <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
        {bullets.map((b) => (
          <li key={b} className="flex gap-2">
            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary/60" aria-hidden="true" />
            <span className="leading-relaxed">{b}</span>
          </li>
        ))}
      </ul>

      <button
        onClick={onCta}
        className="mt-5 inline-flex items-center justify-center rounded-2xl border border-border/70 bg-background/70 px-4 py-2.5 text-sm font-extrabold text-foreground shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:bg-background hover:shadow-premium focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
        data-testid={`service-card-cta-${title}`}
      >
        Prendre RDV pour ce soin
      </button>
    </div>
  );
}
