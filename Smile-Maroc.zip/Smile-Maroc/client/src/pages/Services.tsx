import {
  Braces,
  Sparkles,
  ShieldCheck,
  Stethoscope,
  Syringe,
  Zap,
  ArrowRight,
} from "lucide-react";
import Seo from "@/components/Seo";
import Shell from "@/components/Shell";
import SectionHeading from "@/components/SectionHeading";
import ServiceCard from "@/components/ServiceCard";
import GradientButton from "@/components/GradientButton";
import { siteConfig } from "@/components/SiteConfig";

const services = [
  {
    title: "Soins dentaires généraux",
    icon: Stethoscope,
    bullets: [
      "Consultation & diagnostic",
      "Soins conservateurs (caries, sensibilités)",
      "Conseils d’hygiène et prévention",
    ],
  },
  {
    title: "Détartrage",
    icon: ShieldCheck,
    bullets: [
      "Nettoyage professionnel complet",
      "Prévention des inflammations",
      "Sensation de fraîcheur durable",
    ],
    highlight: "Hygiène & prévention",
  },
  {
    title: "Blanchiment",
    icon: Sparkles,
    bullets: [
      "Éclaircissement esthétique du sourire",
      "Approche progressive & contrôlée",
      "Conseils pour préserver le résultat",
    ],
    highlight: "Sourire lumineux",
  },
  {
    title: "Implants",
    icon: Syringe,
    bullets: [
      "Remplacement stable des dents manquantes",
      "Étude personnalisée",
      "Objectif: confort & mastication",
    ],
    highlight: "Solution durable",
  },
  {
    title: "Orthodontie",
    icon: Braces,
    bullets: [
      "Alignement esthétique & fonctionnel",
      "Suivi régulier et progressif",
      "Solutions adaptées selon le cas",
    ],
    highlight: "Alignement",
  },
  {
    title: "Urgences dentaires",
    icon: Zap,
    bullets: [
      "Douleur, infection, gonflement",
      "Dent cassée / traumatisme",
      "Prise en charge rapide",
    ],
    highlight: "Priorité urgences",
  },
];

export default function Services() {
  const waHref = siteConfig.whatsappHref(
    "Bonjour, je souhaite prendre rendez-vous. Pouvez-vous me proposer un créneau ?",
  );

  return (
    <Shell>
      <Seo
        title="Nos soins"
        description="Découvrez les soins proposés par le Cabinet Dentaire Dr. Ahmed Rida FADIL à El Jadida : détartrage, blanchiment, implants, orthodontie et urgences."
        path="/soins"
        keywords="Dentiste El Jadida, Détartrage El Jadida, Blanchiment El Jadida, Implant dentaire El Jadida, Orthodontie El Jadida, Urgence dentaire El Jadida"
      />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 md:pt-14" data-testid="services-page">
        <SectionHeading
          kicker="Nos soins"
          title="Des soins précis, modernes, et orientés résultats"
          description="Choisissez votre besoin. Pour un RDV rapide, WhatsApp est le canal le plus direct — ou appelez-nous."
        />

        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => (
            <ServiceCard
              key={s.title}
              icon={s.icon}
              title={s.title}
              bullets={s.bullets}
              highlight={s.highlight}
              onCta={() => {
                window.location.href = `/rendez-vous?service=${encodeURIComponent(s.title)}`;
              }}
            />
          ))}
        </div>

        <div className="mt-10 grid grid-cols-1 gap-4 lg:grid-cols-12 lg:items-center">
          <div className="lg:col-span-8">
            <div className="rounded-[2rem] border border-border/70 bg-card/70 p-6 shadow-premium backdrop-blur noise-overlay">
              <div className="text-sm font-extrabold tracking-tight">Besoin d’aide pour choisir ?</div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Décrivez votre situation (douleur, contrôle, esthétique…). Nous vous orientons vers le soin adapté.
              </p>
              <div className="mt-5 flex flex-col gap-3 sm:flex-row">
                <a href={siteConfig.phoneHref} data-testid="services-call" onClick={() => {}}>
                  <GradientButton variant="primary" size="lg" className="w-full sm:w-auto">
                    Appeler maintenant
                    <ArrowRight className="h-5 w-5" />
                  </GradientButton>
                </a>
                <a href={waHref} target="_blank" rel="noreferrer" data-testid="services-wa" onClick={() => {}}>
                  <GradientButton variant="accent" size="lg" className="w-full sm:w-auto">
                    WhatsApp RDV
                    <ArrowRight className="h-5 w-5" />
                  </GradientButton>
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-4">
            <div className="rounded-[2rem] border border-border/70 bg-gradient-to-br from-primary/10 via-card/70 to-accent/10 p-6 shadow-premium backdrop-blur">
              <div className="text-xs font-extrabold text-muted-foreground">À retenir</div>
              <div className="mt-3 space-y-3 text-sm text-muted-foreground">
                <div className="rounded-2xl bg-background/70 p-4">
                  <div className="font-extrabold text-foreground">Dentiste El Jadida</div>
                  <div className="mt-1 text-xs">
                    Cabinet dentaire à El Jadida, accès simple — {siteConfig.locationLine}.
                  </div>
                </div>
                <div className="rounded-2xl bg-background/70 p-4">
                  <div className="font-extrabold text-foreground">Urgence dentaire</div>
                  <div className="mt-1 text-xs">
                    En cas de douleur: appelez ou WhatsApp pour une prise en charge rapide.
                  </div>
                </div>
              </div>

              <button
                type="button"
                data-testid="services-to-contact"
                onClick={() => {
                  window.location.href = "/contact";
                }}
                className="mt-5 inline-flex w-full items-center justify-center rounded-2xl border border-border/70 bg-background/70 px-5 py-4 text-sm font-extrabold text-foreground shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
              >
                Voir la localisation & contact
              </button>
            </div>
          </div>
        </div>
      </section>

      <div className="h-14" />
    </Shell>
  );
}
