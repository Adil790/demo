import { Award, Microscope, ShieldCheck, Sparkles, Stethoscope } from "lucide-react";
import Seo from "@/components/Seo";
import Shell from "@/components/Shell";
import SectionHeading from "@/components/SectionHeading";
import IconPill from "@/components/IconPill";
import GradientButton from "@/components/GradientButton";
import { siteConfig } from "@/components/SiteConfig";

export default function About() {
  const waHref = siteConfig.whatsappHref(
    "Bonjour Dr. Ahmed Rida FADIL, je souhaite prendre rendez-vous (contrôle / soins).",
  );

  return (
    <Shell>
      <Seo
        title="À propos du cabinet"
        description="Découvrez le Cabinet Dentaire Dr. Ahmed Rida FADIL à El Jadida : approche professionnelle, hygiène stricte et technologies modernes."
        path="/a-propos"
      />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 md:pt-14" data-testid="about-page">
        <div className="relative overflow-hidden rounded-[2.25rem] border border-border/70 bg-card/70 p-8 shadow-premium backdrop-blur noise-overlay">
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/12 blur-2xl" />
          <div className="absolute -left-10 -bottom-10 h-40 w-40 rounded-full bg-accent/12 blur-2xl" />

          <SectionHeading
            kicker="À propos"
            title="Une dentisterie moderne, sérieuse et centrée sur le patient"
            description="Le Dr. Ahmed Rida FADIL vous accueille à El Jadida avec une exigence forte : hygiène, précision, et confort — pour des soins durables et une confiance totale."
          />

          <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-3">
            <IconPill
              icon={Award}
              title="Expérience & sérieux"
              description="Une approche structurée, des explications claires, et un suivi attentif."
              tone="primary"
            />
            <IconPill
              icon={Microscope}
              title="Technologies modernes"
              description="Outils et techniques actuels pour un diagnostic précis et des soins efficaces."
              tone="accent"
            />
            <IconPill
              icon={ShieldCheck}
              title="Hygiène irréprochable"
              description="Protocole strict, environnement propre, instruments stérilisés."
              tone="accent"
            />
          </div>

          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
            <div className="lg:col-span-7">
              <div className="rounded-3xl border border-border/70 bg-background/60 p-6 shadow-sm">
                <h3 className="text-xl font-bold">Le Dr. Ahmed Rida FADIL</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  Dentiste expérimenté, le Dr. Ahmed Rida FADIL privilégie une dentisterie
                  moderne et rigoureuse : diagnostic précis, plans de traitement adaptés
                  et accompagnement tout au long du parcours de soins.
                </p>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  Chaque consultation est pensée pour vous rassurer : écoute, explications
                  simples, et attention au confort. L’objectif est clair : des soins
                  durables, esthétiques et fonctionnels.
                </p>

                <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div className="rounded-2xl bg-card/70 p-4">
                    <div className="flex items-center gap-3">
                      <Stethoscope className="h-5 w-5 text-primary" />
                      <div>
                        <div className="text-sm font-extrabold">Approche complète</div>
                        <div className="text-xs text-muted-foreground">Prévention, soins, esthétique</div>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-card/70 p-4">
                    <div className="flex items-center gap-3">
                      <Sparkles className="h-5 w-5 text-accent" />
                      <div>
                        <div className="text-sm font-extrabold">Confort patient</div>
                        <div className="text-xs text-muted-foreground">Rassurant, précis, attentif</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                  <a href={siteConfig.phoneHref} data-testid="about-call" onClick={() => {}}>
                    <GradientButton variant="primary" size="lg" className="w-full sm:w-auto">
                      Appeler maintenant
                    </GradientButton>
                  </a>
                  <a href={waHref} target="_blank" rel="noreferrer" data-testid="about-wa" onClick={() => {}}>
                    <GradientButton variant="accent" size="lg" className="w-full sm:w-auto">
                      WhatsApp RDV
                    </GradientButton>
                  </a>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="rounded-3xl border border-border/70 bg-gradient-to-br from-primary/10 via-card/70 to-accent/10 p-6 shadow-premium backdrop-blur noise-overlay">
                <div className="text-xs font-extrabold text-muted-foreground">Adresse</div>
                <div className="mt-2 text-base font-extrabold">{siteConfig.address}</div>
                <div className="mt-1 text-sm text-muted-foreground">{siteConfig.locationLine}</div>

                <div className="mt-5 rounded-2xl border border-border/60 bg-background/70 p-4">
                  <div className="text-sm font-extrabold">Pourquoi les patients nous choisissent</div>
                  <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                    <li className="flex gap-2">
                      <span className="mt-2 h-1.5 w-1.5 rounded-full bg-primary/70" aria-hidden="true" />
                      <span>Propreté médicale & organisation</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 h-1.5 w-1.5 rounded-full bg-accent/70" aria-hidden="true" />
                      <span>Explications claires, plan de soins transparent</span>
                    </li>
                    <li className="flex gap-2">
                      <span className="mt-2 h-1.5 w-1.5 rounded-full bg-primary/70" aria-hidden="true" />
                      <span>Prise de RDV rapide (WhatsApp / appel)</span>
                    </li>
                  </ul>
                </div>

                <a
                  href="/rendez-vous"
                  data-testid="about-to-rdv"
                  onClick={(e) => {
                    e.preventDefault();
                    window.location.href = "/rendez-vous";
                  }}
                  className="mt-5 inline-flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-primary to-primary/80 px-5 py-4 text-sm font-extrabold text-primary-foreground shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
                >
                  Prendre rendez-vous
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="h-14" />
    </Shell>
  );
}
