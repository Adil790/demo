import { useMemo } from "react";
import { useLocation } from "wouter";
import { MessageCircle, Phone, Sparkles, ShieldCheck } from "lucide-react";
import Seo from "@/components/Seo";
import Shell from "@/components/Shell";
import SectionHeading from "@/components/SectionHeading";
import GradientButton from "@/components/GradientButton";
import LeadForm from "@/components/LeadForm";
import { siteConfig } from "@/components/SiteConfig";

function useQueryParam(name: string) {
  const [location] = useLocation();
  return useMemo(() => {
    const idx = location.indexOf("?");
    if (idx < 0) return null;
    const params = new URLSearchParams(location.slice(idx + 1));
    return params.get(name);
  }, [location, name]);
}

export default function Appointment() {
  const service = useQueryParam("service") ?? undefined;

  const waHref = siteConfig.whatsappHref(
    service
      ? `Bonjour, je souhaite prendre rendez-vous concernant: ${service}.`
      : "Bonjour, je souhaite prendre rendez-vous.",
  );

  return (
    <Shell>
      <Seo
        title="Prendre rendez-vous"
        description="Prenez rendez-vous rapidement au Cabinet Dentaire Dr. Ahmed Rida FADIL à El Jadida. Appel direct ou WhatsApp RDV."
        path="/rendez-vous"
      />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 md:pt-14" data-testid="appointment-page">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-start">
          <div className="lg:col-span-6">
            <SectionHeading
              kicker="Rendez-vous"
              title="Le plus rapide: WhatsApp ou un appel"
              description="Vous pouvez contacter le cabinet immédiatement. Si vous le souhaitez, laissez aussi une demande via le mini-formulaire (suivi interne)."
            />

            <div className="mt-6 rounded-[2rem] border border-border/70 bg-gradient-to-br from-primary/10 via-card/70 to-accent/10 p-6 shadow-premium backdrop-blur noise-overlay">
              <div className="flex flex-col gap-3 sm:flex-row">
                <a href={siteConfig.phoneHref} data-testid="rdv-call" onClick={() => {}} className="w-full sm:w-auto">
                  <GradientButton variant="primary" size="lg" className="w-full sm:w-auto">
                    <Phone className="h-5 w-5" />
                    Appeler maintenant
                  </GradientButton>
                </a>
                <a href={waHref} target="_blank" rel="noreferrer" data-testid="rdv-wa" onClick={() => {}} className="w-full sm:w-auto">
                  <GradientButton variant="accent" size="lg" className="w-full sm:w-auto">
                    <MessageCircle className="h-5 w-5" />
                    WhatsApp RDV
                  </GradientButton>
                </a>
              </div>

              <div className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-border/60 bg-background/70 p-4 shadow-sm">
                  <div className="flex items-center gap-3">
                    <Sparkles className="h-5 w-5 text-accent" />
                    <div>
                      <div className="text-sm font-extrabold">Numéro WhatsApp</div>
                      <div className="text-sm text-muted-foreground">{siteConfig.whatsappDisplay}</div>
                    </div>
                  </div>
                </div>
                <div className="rounded-2xl border border-border/60 bg-background/70 p-4 shadow-sm">
                  <div className="flex items-center gap-3">
                    <ShieldCheck className="h-5 w-5 text-primary" />
                    <div>
                      <div className="text-sm font-extrabold">Téléphone</div>
                      <div className="text-sm text-muted-foreground">{siteConfig.phoneDisplay}</div>
                    </div>
                  </div>
                </div>
              </div>

              {service && (
                <div className="mt-4 rounded-2xl bg-accent/12 px-4 py-3 text-sm font-extrabold text-accent" data-testid="rdv-service-selected">
                  Soin sélectionné: {service}
                </div>
              )}
            </div>

            <div className="mt-6 rounded-3xl border border-border/70 bg-card/70 p-6 shadow-sm backdrop-blur">
              <div className="text-sm font-extrabold tracking-tight">Astuce conversion</div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Pour une réponse plus rapide, envoyez sur WhatsApp:{" "}
                <span className="font-extrabold text-foreground">Nom + téléphone + votre besoin</span>.
              </p>
              <button
                type="button"
                data-testid="rdv-copy-template"
                onClick={async () => {
                  const template = service
                    ? `Bonjour, je souhaite un rendez-vous.\nNom: \nTéléphone: \nSoin: ${service}\nDisponibilités: `
                    : "Bonjour, je souhaite un rendez-vous.\nNom: \nTéléphone: \nBesoin: \nDisponibilités: ";
                  try {
                    await navigator.clipboard.writeText(template);
                  } catch {
                    // ignore
                  }
                  window.open(siteConfig.whatsappHref(template), "_blank", "noopener,noreferrer");
                }}
                className="mt-4 inline-flex w-full items-center justify-center rounded-2xl border border-border/70 bg-background/70 px-5 py-4 text-sm font-extrabold text-foreground shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
              >
                Ouvrir WhatsApp avec un message modèle
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <LeadForm
              defaultService={service}
              onSubmitted={() => {
                // Keep user on page; conversion already happened.
              }}
            />
          </div>
        </div>
      </section>

      <div className="h-14" />
    </Shell>
  );
}
