import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  BadgeCheck,
  Clock,
  MapPin,
  Phone,
  MessageCircle,
  Sparkles,
  ShieldCheck,
  Stethoscope,
  Syringe,
} from "lucide-react";
import Seo from "@/components/Seo";
import Shell from "@/components/Shell";
import SectionHeading from "@/components/SectionHeading";
import GradientButton from "@/components/GradientButton";
import IconPill from "@/components/IconPill";
import ServiceCard from "@/components/ServiceCard";
import { siteConfig } from "@/components/SiteConfig";

import clinicHero from "@/assets/clinic-hero.jpg";
import patientSmile from "@/assets/patient-smile.jpg";

const servicesPreview = [
  {
    title: "Soins dentaires généraux",
    icon: Stethoscope,
    bullets: ["Contrôle & diagnostic", "Soins conservateurs", "Conseils d'hygiène personnalisés"],
  },
  {
    title: "Détartrage",
    icon: ShieldCheck,
    bullets: ["Nettoyage professionnel", "Gencives plus saines", "Prévention durable"],
    highlight: "Recommandé 1–2 fois/an",
  },
  {
    title: "Urgences dentaires",
    icon: Syringe,
    bullets: ["Douleur / infection", "Dent cassée", "Prise en charge rapide"],
    highlight: "Priorité aux urgences",
  },
];

export default function Home() {
  const waHref = siteConfig.whatsappHref(
    "Bonjour, je souhaite prendre rendez-vous au Cabinet Dentaire Dr. Ahmed Rida FADIL à El Jadida.",
  );

  return (
    <Shell>
      <Seo
        title="Votre sourire, notre priorité"
        description="Soins dentaires modernes à El Jadida. Cabinet dentaire Dr. Ahmed Rida FADIL — prise de rendez-vous rapide par WhatsApp ou appel."
        path="/"
        keywords="Dentiste El Jadida, Cabinet dentaire El Jadida, Urgence dentaire El Jadida, Détartrage, Blanchiment, Implants, Orthodontie"
      />

      {/* Hero */}
      <section className="relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 md:pt-14">
          <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 lg:items-center">
            <div className="lg:col-span-7">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="animate-in-up"
                data-testid="hero"
              >
                <div className="inline-flex items-center gap-2 rounded-full border border-border/70 bg-card/70 px-3 py-1 text-xs font-extrabold text-muted-foreground shadow-sm backdrop-blur">
                  <Sparkles className="h-4 w-4 text-accent" />
                  Cabinet dentaire à El Jadida • Hygiène & technologies modernes
                </div>

                <h1 className="mt-5 text-4xl font-bold leading-[1.05] md:text-5xl lg:text-6xl">
                  <span className="text-foreground">Votre sourire,</span>{" "}
                  <span className="text-gradient-medical">notre priorité</span>
                </h1>

                <p className="mt-4 max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
                  Soins dentaires modernes à El Jadida. Une expérience claire, sereine et professionnelle — du diagnostic à la prise en charge.
                </p>

                <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center" data-testid="hero-cta">
                  <a href={siteConfig.phoneHref} data-testid="cta-call" onClick={() => {}}>
                    <GradientButton variant="primary" size="lg" className="w-full sm:w-auto">
                      <Phone className="h-5 w-5" />
                      Appeler maintenant
                    </GradientButton>
                  </a>

                  <a href={waHref} target="_blank" rel="noreferrer" data-testid="cta-whatsapp" onClick={() => {}}>
                    <GradientButton variant="accent" size="lg" className="w-full sm:w-auto">
                      <MessageCircle className="h-5 w-5" />
                      Prendre RDV sur WhatsApp
                    </GradientButton>
                  </a>

                  <Link
                    href="/soins"
                    className="w-full sm:w-auto rounded-2xl border border-border/70 bg-card/70 px-6 py-4 text-center text-base font-extrabold text-foreground shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
                    data-testid="cta-services"
                  >
                    Voir les soins
                  </Link>
                </div>

                <div className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-3" data-testid="trust-badges">
                  <div className="rounded-2xl border border-border/70 bg-card/70 p-4 shadow-sm backdrop-blur">
                    <div className="flex items-center gap-3">
                      <div className="grid h-10 w-10 place-items-center rounded-2xl bg-primary/10">
                        <BadgeCheck className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm font-extrabold">Confiance</div>
                        <div className="text-xs text-muted-foreground">Approche sérieuse & transparente</div>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-border/70 bg-card/70 p-4 shadow-sm backdrop-blur">
                    <div className="flex items-center gap-3">
                      <div className="grid h-10 w-10 place-items-center rounded-2xl bg-accent/10">
                        <ShieldCheck className="h-5 w-5 text-accent" />
                      </div>
                      <div>
                        <div className="text-sm font-extrabold">Hygiène</div>
                        <div className="text-xs text-muted-foreground">Propreté médicale, protocole strict</div>
                      </div>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-border/70 bg-card/70 p-4 shadow-sm backdrop-blur">
                    <div className="flex items-center gap-3">
                      <div className="grid h-10 w-10 place-items-center rounded-2xl bg-primary/10">
                        <Clock className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm font-extrabold">Rapide</div>
                        <div className="text-xs text-muted-foreground">RDV WhatsApp & appel direct</div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative overflow-hidden rounded-[2.5rem] border border-border/70 shadow-2xl animate-in-fade group">
                <img 
                  src={clinicHero} 
                  alt="Cabinet Dentaire Moderne" 
                  className="h-full w-full object-cover aspect-[4/5] transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                
                <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
                  <div className="inline-flex items-center gap-2 rounded-full bg-white/20 backdrop-blur-md px-3 py-1 text-xs font-bold mb-3">
                    <MapPin className="h-3.5 w-3.5" />
                    El Jadida
                  </div>
                  <h3 className="text-xl font-bold">{siteConfig.clinicName}</h3>
                  <p className="text-sm text-white/80 mt-1">{siteConfig.address}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick value props */}
          <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-3" data-testid="value-props">
            <IconPill
              icon={ShieldCheck}
              title="Propreté médicale"
              description="Protocoles d’hygiène stricts, instruments stérilisés, environnement impeccable."
              tone="accent"
            />
            <IconPill
              icon={Stethoscope}
              title="Diagnostic précis"
              description="Explications simples, plan de traitement clair, suivi patient."
              tone="primary"
            />
            <IconPill
              icon={BadgeCheck}
              title="Soin orienté confiance"
              description="Approche rassurante, écoute, et confort tout au long du soin."
              tone="primary"
            />
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="mt-16 md:mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeading
            kicker="Nos soins"
            title="Une prise en charge complète, du contrôle à l’urgence"
            description="Des soins adaptés, avec une attention particulière à la précision, l’hygiène et la durabilité."
          />

          <div className="mt-8 grid grid-cols-1 gap-4 lg:grid-cols-3">
            {servicesPreview.map((s, idx) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.45, delay: idx * 0.06 }}
              >
                <ServiceCard
                  icon={s.icon}
                  title={s.title}
                  bullets={s.bullets}
                  highlight={s.highlight}
                  onCta={() => {
                    window.location.href = `/rendez-vous?service=${encodeURIComponent(s.title)}`;
                  }}
                />
              </motion.div>
            ))}
          </div>

          <div className="mt-16 relative overflow-hidden rounded-[2.5rem] border border-border/70 bg-card/50 shadow-premium">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <BadgeCheck className="h-8 w-8 text-primary mb-4" />
                <h2 className="text-3xl font-bold leading-tight">Pourquoi nous faire confiance ?</h2>
                <p className="mt-4 text-muted-foreground leading-relaxed">
                  Au Cabinet Dr. Ahmed Rida FADIL, nous combinons expertise clinique et technologies de pointe pour vous offrir les meilleurs soins. Notre engagement est de rendre chaque visite aussi confortable que possible.
                </p>
                <div className="mt-8 grid grid-cols-2 gap-6">
                  <div>
                    <div className="text-2xl font-bold text-primary">99%</div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Satisfaction</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">100%</div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Hygiène</div>
                  </div>
                </div>
              </div>
              <div className="relative min-h-[300px]">
                <img 
                  src={patientSmile} 
                  alt="Patient satisfait" 
                  className="absolute inset-0 h-full w-full object-cover"
                />
              </div>
            </div>
          </div>

          <div className="h-14" />
        </div>
      </section>

      {/* Conversion section */}
      <section className="mt-16 md:mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-[2.25rem] border border-border/70 bg-gradient-to-br from-primary/12 via-card/70 to-accent/10 p-8 shadow-premium backdrop-blur noise-overlay">
            <div className="absolute -right-14 -top-14 h-56 w-56 rounded-full bg-primary/18 blur-3xl animate-float" />
            <div className="absolute -left-14 -bottom-14 h-56 w-56 rounded-full bg-accent/18 blur-3xl animate-float" />

            <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center">
              <div className="lg:col-span-7">
                <div className="inline-flex items-center gap-2 rounded-full bg-background/70 px-3 py-1 text-xs font-extrabold text-muted-foreground shadow-sm">
                  <MapPin className="h-4 w-4 text-primary" />
                  {siteConfig.locationLine}
                </div>
                <h2 className="mt-4 text-3xl font-bold leading-tight md:text-4xl">
                  Prendre rendez-vous{" "}
                  <span className="text-gradient-medical">en quelques secondes</span>
                </h2>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground md:text-base">
                  Pour un contrôle, un détartrage, une urgence ou un traitement esthétique — contactez-nous directement par appel ou WhatsApp.
                </p>
                <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                  <a href={siteConfig.phoneHref} data-testid="home-bottom-call" onClick={() => {}}>
                    <GradientButton variant="primary" size="lg" className="w-full sm:w-auto">
                      <Phone className="h-5 w-5" />
                      Appeler maintenant
                    </GradientButton>
                  </a>
                  <a href={waHref} target="_blank" rel="noreferrer" data-testid="home-bottom-wa" onClick={() => {}}>
                    <GradientButton variant="accent" size="lg" className="w-full sm:w-auto">
                      <MessageCircle className="h-5 w-5" />
                      WhatsApp RDV
                    </GradientButton>
                  </a>
                </div>
              </div>

              <div className="lg:col-span-5">
                <div className="rounded-3xl border border-border/70 bg-background/60 p-6 shadow-sm">
                  <div className="text-sm font-extrabold tracking-tight">Infos utiles</div>
                  <div className="mt-4 grid grid-cols-1 gap-3 text-sm">
                    <div className="rounded-2xl bg-card/70 p-4">
                      <div className="flex items-center gap-3">
                        <Phone className="h-4 w-4 text-primary" />
                        <div>
                          <div className="font-extrabold">Téléphone</div>
                          <div className="text-muted-foreground">{siteConfig.phoneDisplay}</div>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-2xl bg-card/70 p-4">
                      <div className="flex items-center gap-3">
                        <MessageCircle className="h-4 w-4 text-accent" />
                        <div>
                          <div className="font-extrabold">WhatsApp RDV</div>
                          <div className="text-muted-foreground">{siteConfig.whatsappDisplay}</div>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-2xl bg-card/70 p-4">
                      <div className="flex items-center gap-3">
                        <MapPin className="h-4 w-4 text-primary" />
                        <div>
                          <div className="font-extrabold">Adresse</div>
                          <div className="text-muted-foreground">{siteConfig.address}</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Link
                    href="/rendez-vous"
                    className="mt-5 block rounded-2xl bg-gradient-to-r from-primary to-primary/80 px-5 py-4 text-center text-sm font-extrabold text-primary-foreground shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
                    data-testid="home-to-rdv-page"
                  >
                    Aller à la page Rendez-vous
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="h-14" />
    </Shell>
  );
}
