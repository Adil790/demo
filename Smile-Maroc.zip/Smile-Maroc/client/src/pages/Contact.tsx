import { MapPin, Phone, MessageCircle, ExternalLink } from "lucide-react";
import Seo from "@/components/Seo";
import Shell from "@/components/Shell";
import SectionHeading from "@/components/SectionHeading";
import GradientButton from "@/components/GradientButton";
import { siteConfig } from "@/components/SiteConfig";

export default function Contact() {
  const waHref = siteConfig.whatsappHref(
    "Bonjour, je souhaite prendre rendez-vous. Pouvez-vous me partager vos disponibilités ?",
  );

  const mapsLink = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(siteConfig.address);

  return (
    <Shell>
      <Seo
        title="Contact & localisation"
        description="Contactez le Cabinet Dentaire Dr. Ahmed Rida FADIL à El Jadida. Adresse, téléphone, WhatsApp RDV, et carte Google Maps."
        path="/contact"
        keywords="Contact Dentiste El Jadida, Adresse cabinet dentaire El Jadida, WhatsApp dentiste El Jadida, Téléphone dentiste El Jadida"
      />

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 md:pt-14" data-testid="contact-page">
        <SectionHeading
          kicker="Contact"
          title="Localisation simple, contact immédiat"
          description="Face à Bank Al Maghrib — Résidence Alami. Pour un RDV rapide: WhatsApp ou appel."
        />

        <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-12 lg:items-start">
          <div className="lg:col-span-5">
            <div className="rounded-[2rem] border border-border/70 bg-card/70 p-6 shadow-premium backdrop-blur noise-overlay">
              <div className="space-y-4">
                <div className="rounded-2xl border border-border/60 bg-background/70 p-4 shadow-sm">
                  <div className="flex items-start gap-3">
                    <MapPin className="mt-0.5 h-5 w-5 text-primary" />
                    <div>
                      <div className="text-sm font-extrabold">Adresse</div>
                      <div className="mt-1 text-sm text-muted-foreground leading-relaxed">
                        {siteConfig.address}
                        <div className="mt-1 text-xs">{siteConfig.locationLine}</div>
                      </div>
                      <a
                        href={mapsLink}
                        target="_blank"
                        rel="noreferrer"
                        data-testid="contact-open-maps"
                        onClick={() => {}}
                        className="mt-3 inline-flex items-center gap-2 rounded-xl bg-primary/10 px-3 py-2 text-xs font-extrabold text-primary hover:bg-primary/15 transition"
                      >
                        Ouvrir dans Google Maps <ExternalLink className="h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="rounded-2xl border border-border/60 bg-background/70 p-4 shadow-sm">
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-primary" />
                    <div className="min-w-0">
                      <div className="text-sm font-extrabold">Téléphone</div>
                      <a
                        href={siteConfig.phoneHref}
                        data-testid="contact-phone"
                        onClick={() => {}}
                        className="mt-1 block truncate text-sm font-semibold text-foreground underline decoration-primary/20 hover:decoration-primary/60"
                      >
                        {siteConfig.phoneDisplay}
                      </a>
                    </div>
                  </div>
                </div>

                <div className="rounded-2xl border border-border/60 bg-background/70 p-4 shadow-sm">
                  <div className="flex items-center gap-3">
                    <MessageCircle className="h-5 w-5 text-accent" />
                    <div className="min-w-0">
                      <div className="text-sm font-extrabold">WhatsApp RDV</div>
                      <a
                        href={waHref}
                        target="_blank"
                        rel="noreferrer"
                        data-testid="contact-whatsapp"
                        onClick={() => {}}
                        className="mt-1 block truncate text-sm font-semibold text-foreground underline decoration-accent/20 hover:decoration-accent/60"
                      >
                        {siteConfig.whatsappDisplay}
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <a href={siteConfig.phoneHref} data-testid="contact-cta-call" onClick={() => {}} className="w-full sm:w-auto">
                  <GradientButton variant="primary" size="lg" className="w-full sm:w-auto">
                    Appeler maintenant
                  </GradientButton>
                </a>
                <a href={waHref} target="_blank" rel="noreferrer" data-testid="contact-cta-wa" onClick={() => {}} className="w-full sm:w-auto">
                  <GradientButton variant="accent" size="lg" className="w-full sm:w-auto">
                    WhatsApp RDV
                  </GradientButton>
                </a>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className="overflow-hidden rounded-[2rem] border border-border/70 bg-card/70 shadow-premium backdrop-blur" data-testid="contact-map">
              <div className="flex items-center justify-between gap-3 border-b border-border/70 px-5 py-4">
                <div className="text-sm font-extrabold tracking-tight">Carte Google Maps</div>
                <a
                  href={mapsLink}
                  target="_blank"
                  rel="noreferrer"
                  data-testid="contact-map-external"
                  onClick={() => {}}
                  className="inline-flex items-center gap-2 rounded-xl bg-background/70 px-3 py-2 text-xs font-extrabold text-foreground hover:shadow-sm transition"
                >
                  Itinéraire <ExternalLink className="h-4 w-4" />
                </a>
              </div>
              <iframe
                title="Localisation du cabinet"
                src={siteConfig.mapsEmbedUrl}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-[420px] w-full"
              />
            </div>

            <div className="mt-6 rounded-[2rem] border border-border/70 bg-gradient-to-br from-primary/10 via-card/70 to-accent/10 p-6 shadow-premium backdrop-blur noise-overlay">
              <div className="text-sm font-extrabold tracking-tight">SEO local (El Jadida)</div>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                Vous recherchez un <span className="font-extrabold text-foreground">Dentiste El Jadida</span> ?
                Notre cabinet dentaire à El Jadida vous accompagne pour les soins, l’esthétique et l’urgence dentaire.
              </p>
              <button
                type="button"
                data-testid="contact-to-rdv"
                onClick={() => {
                  window.location.href = "/rendez-vous";
                }}
                className="mt-4 inline-flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-primary to-primary/80 px-5 py-4 text-sm font-extrabold text-primary-foreground shadow-premium transition-all duration-300 hover:-translate-y-0.5 hover:shadow-premium-lg focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-ring/20"
              >
                Prendre rendez-vous
              </button>
            </div>
          </div>
        </div>
      </section>

      <div className="h-14" />
    </Shell>
  );
}
