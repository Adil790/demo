import { pgTable, text, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Static marketing site: keep schema minimal.
// We store only lead/contact requests to track conversion.

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  preferredChannel: text("preferred_channel").notNull(), // 'whatsapp' | 'call' | 'email'
  message: text("message").notNull(),
  service: text("service"),
});

export const insertLeadSchema = createInsertSchema(leads).omit({ id: true });

// Base types
export type Lead = typeof leads.$inferSelect;
export type InsertLead = z.infer<typeof insertLeadSchema>;

// Explicit API contract types
export type CreateLeadRequest = InsertLead;
export type LeadResponse = Lead;
export type LeadsListResponse = Lead[];

export const SERVICE_OPTIONS = [
  "Soins dentaires généraux",
  "Détartrage",
  "Blanchiment",
  "Implants",
  "Orthodontie",
  "Urgences dentaires",
] as const;

export type ServiceOption = (typeof SERVICE_OPTIONS)[number];
